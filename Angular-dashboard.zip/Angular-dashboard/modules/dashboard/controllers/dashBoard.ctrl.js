function baseController($scope, dataService) {
    $scope.buildList = dataService.buildVersions;
    $scope.displayBuildDetails = function () {
        console.log("Selected Value : " + $scope.selectedOption);
    }
}
dashBoard.controller('baseController', baseController);