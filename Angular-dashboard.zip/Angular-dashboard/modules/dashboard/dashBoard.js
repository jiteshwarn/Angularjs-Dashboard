
"use strict";
var dashBoard = angular.module('dashBoard', ['ui.router']);
dashBoard.config(["$stateProvider",
    "$urlRouterProvider",
    function ($stateProvider, $urlRouterProvider) {

        $stateProvider
            .state("dashboard", {
                url: "/newpage",
                templateUrl: "./widget/test.html"
            });

        $urlRouterProvider.otherwise("/");

    }]);