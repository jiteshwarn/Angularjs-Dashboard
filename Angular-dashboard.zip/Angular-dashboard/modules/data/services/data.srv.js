function dataService() {
    return {
        buildVersions: ['111', '112', '113', '114', '115']
    }
}

dashBoard.factory('dataService', dataService);