var app = angular.module("ReportApp", []);
app.controller("ReportHeaderController", function ($scope) {
    $scope.name = "meena";
    var date = new Date();
    $scope.date = date.toDateString();

    $scope.builds = [
        { "buildversion": "1.0.0" }, {

            "buildversion": "2.0.0"
        }, {

            "buildversion": "3.0.0"
        }
    ];
});


app.controller("ReportBuildContriller", function ($scope, $http) {
    $http.get("https://api.myjson.com/bins/a5umt")
        //$http.get("scripts/builds.json")
        .then(function (response) {
            $scope.builds = response.data;
        });
    $scope.getdropDownValue = function () {
         $scope.dropDownSelectedValue = $("#dropdownbuil").val();
        if ($scope.dropDownSelectedValue !== 'select') {
            console.log($scope.dropDownSelectedValue);
            $http.get("https://api.myjson.com/bins/yq1q9")
                .then(function (res) {
                    $scope.comments = res.data;
                    console.log("before printing" + $scope.comments[0].buildversion);
                });
        }
    }
});
