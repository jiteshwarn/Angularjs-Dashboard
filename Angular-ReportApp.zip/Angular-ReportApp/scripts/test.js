var app = angular.module("ReportApp", []);

app.controller("ReportHeaderController",function($scope,$http){
//$http.get("https://api.myjson.com/bins/a5umt")
//$http.get("https://api.myjson.com/bins/1af1ld")
$http.get("https://api.myjson.com/bins/yq1q9")
//$http.get("https://api.myjson.com/bins/wfkld")
//$http.get("scripts/builds.json")
.then(function(response){
    $scope.comments=response.data;
});
$scope.getdropDownValue=function()
{
     var dropDownSelectedValue=$("#dropdownbuil").val();
  //console.log(dropDownSelectedValue);

        $http.get("https://api.myjson.com/bins/yq1q9")
        .then(function(res){
            $scope.tables=res.data;
            console.log("before printing"+ $scope.tables[0].buildversion);
          

 });
}
});


